""" module subpar_app """
__version__ = '0.2.0'